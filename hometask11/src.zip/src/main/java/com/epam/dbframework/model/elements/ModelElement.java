package com.epam.dbframework.model.elements;

public abstract class ModelElement {
	public abstract String toValuesString();
}
