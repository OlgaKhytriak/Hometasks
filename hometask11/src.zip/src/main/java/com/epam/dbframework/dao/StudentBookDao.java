package com.epam.dbframework.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.epam.dbframework.handler.ConnectorToDB;

public class StudentBookDao extends BasicDao{
	private static final Logger LOG = Logger.getLogger(StudentBookDao.class);

	
}
