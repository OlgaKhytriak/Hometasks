package com.epam.dbframework.dao;

import org.apache.log4j.Logger;

public class SubjectDao extends BasicDao{
	private static final Logger LOG = Logger.getLogger(SubjectDao.class);
	
	
}
