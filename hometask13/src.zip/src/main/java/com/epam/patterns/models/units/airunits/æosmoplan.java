package com.epam.patterns.models.units.airunits;

import com.epam.patterns.models.units.interfaces.Unit;

public class �osmoplan extends SampleAirUnit {

	public void fight(Unit victim) {
		System.out.println("�osmoplan fights");

	}

	public void fly(int numberOfSteps) {
		System.out.println("�osmoplan fly");

	}

}
