package com.epam.patterns.models.units.interfaces;

public interface AirUnit extends Unit{
public void fly(int numberOfSteps);
}
