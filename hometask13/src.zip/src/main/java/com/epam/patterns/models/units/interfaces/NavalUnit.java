package com.epam.patterns.models.units.interfaces;

public interface NavalUnit extends Unit {
	public void navigate(int numberOfSteps);
}
