package com.epam.patterns.models.weapons;

public class MachineGun extends LandUnitsWeapon{

}
