package com.epam.patterns.models.weapons;

public class �annon extends LandUnitsWeapon{

}
