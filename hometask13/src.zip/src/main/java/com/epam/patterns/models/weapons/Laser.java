package com.epam.patterns.models.weapons;

public class Laser extends LandUnitsWeapon{

}
