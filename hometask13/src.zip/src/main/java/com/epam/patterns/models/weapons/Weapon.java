package com.epam.patterns.models.weapons;

public interface Weapon {

}
