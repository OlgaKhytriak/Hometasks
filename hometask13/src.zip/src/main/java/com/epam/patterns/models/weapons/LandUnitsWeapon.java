package com.epam.patterns.models.weapons;

public abstract class LandUnitsWeapon implements Weapon{

}
