package com.epam.patterns.models.units.interfaces;

public interface LandUnit extends Unit{
	public void go(int numberOfSteps);
}
