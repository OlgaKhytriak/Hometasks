package com.epam.lab.task15.patterns.strategy.models;

public interface BattleDroid extends Droid{
	public void shoot(SimpleDroid enemyDroid);
}
