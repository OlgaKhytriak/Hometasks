package com.epam.lab.task15.patterns.bridge;

public interface Vehicle {
	public void moveRight();
	public void moveLeft();
	public void moveStraight();

}
