package com.epam.lab.task15.patterns.bridge;

public interface Helm {
public void turnLeft();
public void turnRight();
public void keepPosition();
}
