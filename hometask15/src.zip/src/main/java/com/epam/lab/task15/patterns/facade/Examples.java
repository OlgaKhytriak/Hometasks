package com.epam.lab.task15.patterns.facade;

public interface Examples {

	public void useBridgePattern();

	public void useDecoratorPattern();

	public void useStrategyPattern();
}
