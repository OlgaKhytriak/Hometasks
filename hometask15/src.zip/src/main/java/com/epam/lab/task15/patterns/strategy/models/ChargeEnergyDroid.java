package com.epam.lab.task15.patterns.strategy.models;

public interface ChargeEnergyDroid extends Droid{
	public void charge(SimpleDroid injuredDroid);
}
