package com.epam.lab.task15.patterns.strategy.models;

public interface DefenderDroid extends Droid{
	public void defenceItself(SimpleDroid droidAttacker);

}
