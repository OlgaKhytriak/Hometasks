package com.epam.lab.task15.patterns.decorator;

public class SimpleGirl implements Girl{

	public void decorate() {
		System.out.println("Simple girl without decoration");		
	}

}
