package com.epam.lab.task15.patterns.strategy;

public enum StrategyType {
	RANDOM,
	ALTERNATELY

}
