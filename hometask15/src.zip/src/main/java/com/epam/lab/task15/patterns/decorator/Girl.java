package com.epam.lab.task15.patterns.decorator;

public interface Girl {
public void decorate();
}
