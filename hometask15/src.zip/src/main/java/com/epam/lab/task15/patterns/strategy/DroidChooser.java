package com.epam.lab.task15.patterns.strategy;

import com.epam.lab.task15.patterns.strategy.models.SimpleDroid;

public interface DroidChooser {
 public SimpleDroid choose() ;
}
