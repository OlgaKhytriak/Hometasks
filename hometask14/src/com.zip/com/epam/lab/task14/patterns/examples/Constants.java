package com.epam.lab.task14.patterns.examples;

public class Constants {
	public static final String XML_JAXB_FILE_PATH_1 = "internetRateJAXB1.xml";
	public static final String XML_JAXB_FILE_PATH_TARIFF="singleTariff.xml";

}
